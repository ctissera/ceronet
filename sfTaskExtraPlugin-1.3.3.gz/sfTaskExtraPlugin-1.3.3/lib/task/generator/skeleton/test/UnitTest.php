<?php

/**
 * ##CLASS## tests.
 */
include ##BOOTSTRAP##;
##DATABASE##
$t = new lime_test(0);
