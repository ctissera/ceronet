<?php

require_once dirname(__FILE__).'/../sfTaskExtraBaseTask.class.php';

/**
 * Base test task.
 * 
 * @package     sfTaskExtraPlugin
 * @subpackage  task
 * @author      Kris Wallsmith <kris.wallsmith@symfony-project.com>
 * @version     SVN: $Id: sfTaskExtraTestBaseTask.class.php 15353 2009-02-08 21:12:33Z Kris.Wallsmith $
 */
abstract class sfTaskExtraTestBaseTask extends sfTaskExtraBaseTask
{
}
