<?php

/**
 * ##MODEL## form filter class for the ##APPLICATION## application.
 *
 * @package    ##PROJECT##
 * @subpackage filter
 * @author     ##AUTHOR##
 * @version    SVN: $Id: form.class.php 28153 2010-02-20 16:02:12Z Kris.Wallsmith $
 */
class ##APPLICATION####MODEL##FormFilter extends ##MODEL##FormFilter
{
  /**
   * @see sfForm
   */
  public function configure()
  {
    parent::configure();
  }
}
