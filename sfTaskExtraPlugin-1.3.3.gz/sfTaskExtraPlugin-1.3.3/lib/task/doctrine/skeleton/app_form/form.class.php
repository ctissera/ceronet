<?php

/**
 * ##MODEL## form class for the ##APPLICATION## application.
 *
 * @package    ##PROJECT##
 * @subpackage form
 * @author     ##AUTHOR##
 * @version    SVN: $Id: form.class.php 28152 2010-02-20 15:57:55Z Kris.Wallsmith $
 */
class ##APPLICATION####MODEL##Form extends ##MODEL##Form
{
  /**
   * @see sfForm
   */
  public function configure()
  {
    parent::configure();
  }
}
