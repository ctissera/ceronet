<?php

/**
 * ##MODEL## form filter class for the ##APPLICATION## application.
 *
 * @package    ##PROJECT##
 * @subpackage filter
 * @author     ##AUTHOR##
 * @version    SVN: $Id: form.class.php 28187 2010-02-22 16:53:57Z Kris.Wallsmith $
 */
class ##APPLICATION####MODEL##FormFilter extends ##MODEL##FormFilter
{
  /**
   * @see sfForm
   */
  public function configure()
  {
    parent::configure();
  }
}
